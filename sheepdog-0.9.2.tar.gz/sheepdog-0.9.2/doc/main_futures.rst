Main Futures
============

- Simple implementation (2 services only) and intuitive command line.
- Import of existing disks (qcow2, raw).
- Export of Vdi to file (all type supported by qemu).
- Vdi snapshot.
- Vdi cloning.
- Vdi resize.
- Vdi preallocation.
- Cluster snapshot.
- Dedicated nic for data sync.
- Support of live migration.