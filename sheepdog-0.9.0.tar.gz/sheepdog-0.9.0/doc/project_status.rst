Project Status
==============

Sheepdog is actively developed and more supporters are joining the project.
It has reached a good maturity level.
You may use the stable branch or development to test the latest improvements.

You may have a look at the `Developers Mailing List Archive`_ to have an idea of
the project vitality.

We recommend you to join the `Users Mailing List`_ to ask for help and/or offer
some help.

If you are an interested developer, please join the `Developers Mailing List`_ .

.. _`Developers Mailing List Archive`:  http://lists.wpkg.org/pipermail/sheepdog
.. _`Users Mailing List`: http://lists.wpkg.org/mailman/listinfo/sheepdog
.. _`Developers Mailing List`: http://lists.wpkg.org/mailman/listinfo/sheepdog
