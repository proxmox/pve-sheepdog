Author And Licensing
====================

|cc logo| 

This manual has been created by *Valerio Pachera* for the Sheepdog Project and 
it's released under `Creative Commons Attribution 3.0 Unported`_ license.

.. _`Creative Commons Attribution 3.0 Unported`: http://creativecommons.org/licenses/by/3.0/deed.it

.. |cc logo| image:: http://i.creativecommons.org/l/by/3.0/88x31.png
    :scale: 200 %
    :alt: Creative Commons Logo
    :target: http://creativecommons.org/licenses/by/3.0/deed.it
    
.. commento
    